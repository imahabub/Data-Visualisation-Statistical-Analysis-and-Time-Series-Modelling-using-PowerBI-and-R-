#install.packages("ggplot2")
#install.packages("dplyr")
#install.packages("corrplot")
#install.packages("stats")
#installed.packages("readxl")



library(ggplot2)
library(dplyr)
library(corrplot)
library(stats)
library(readxl)

#loading the data set
Energy_Efficiency_Data <- read_excel("C:/Energy Efficiency Data.xlsx")

#checking first few rows of the dataset
head(Energy_Efficiency_Data)

#descriptive analysis
summary(Energy_Efficiency_Data)

#checking null values
colSums(is.na(Energy_Efficiency_Data))


ggplot(Energy_Efficiency_Data, aes(x = `Glazing Area Distribution`, y = `Heating Load`, fill = `Glazing Area Distribution`)) +
  geom_boxplot() +
  theme_minimal() +
  ggtitle("Heating Load by Glazing Area Distribution") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

ggplot(Energy_Efficiency_Data, aes(x = factor(Orientation), y = `Heating Load`, fill = factor(Orientation))) +
  geom_bar(stat = "summary", fun = "mean") +
  theme_minimal() +
  ggtitle("Average Heating Load by Building Orientation") +
  xlab("Orientation") +
  ylab("Average Heating Load")


ggplot(Energy_Efficiency_Data, aes(x = `Wall Area`)) + 
  geom_histogram(binwidth = 10, fill = "red", color = "black") + 
  theme_minimal() + ggtitle("Wall Area Distribution")


pairs(Energy_Efficiency_Data)


# Compute correlation matrix
cor_matrix <- cor(Energy_Efficiency_Data[, c(`Relative Compactness`, `Surface Area`, `Wall Area`, `Roof Area`, `Overall Height`, `Orientation`, `Glazing.Area`, `Glazing Area Distribution`, `Heating Load`, `Cooling Load`)])

# Visualize correlation matrix
corrplot(cor_matrix, method = "circle", type = "lower", tl.col = "black", tl.srt = 45)


# Compute correlation between Heating Load and selected variables
cor(Energy_Efficiency_Data$`Heating Load`, 
    Energy_Efficiency_Data[, c('Relative Compactness', 'Surface Area', 'Wall Area', 'Roof Area', 'Overall Height', 'Orientation', 'Glazing Area', 'Glazing Area Distribution', 'Cooling Load')])

# Compute correlation between Cooling Load and selected variables
cor(Energy_Efficiency_Data$`Cooling Load`, 
    Energy_Efficiency_Data[, c('Relative Compactness', 'Surface Area', 'Wall Area', 'Roof Area', 'Overall Height', 'Orientation', 'Glazing Area', 'Glazing Area Distribution', 'Heating Load')])


#regression analysis of heating model
heating_model <- lm(`Heating Load` ~ `Relative Compactness` + `Surface Area` + `Wall Area` + `Roof Area` + `Overall Height` + `Orientation` + `Glazing Area` + `Glazing Area Distribution`, data = Energy_Efficiency_Data)
summary(heating_model)


#regression analysis of cooling model
cooling_model <- lm(`Cooling Load` ~ `Relative Compactness` + `Surface Area` + `Wall Area` + `Roof Area` + `Overall Height` + `Orientation` + `Glazing Area` + `Glazing Area Distribution`, data = Energy_Efficiency_Data)
summary(cooling_model)


par(mfrow = c(2, 2))  
plot(heating_model)    

#hypothesis 1
heating_compactness_model <- lm(`Heating Load` ~ `Relative Compactness`, data = Energy_Efficiency_Data)
summary(heating_compactness_model)

#hypothesis 2
cooling_glazing_model <- lm(`Cooling Load` ~ `Glazing Area`, data = Energy_Efficiency_Data)
summary(cooling_glazing_model)











