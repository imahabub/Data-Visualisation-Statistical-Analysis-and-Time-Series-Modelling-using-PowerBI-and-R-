# Load the data and check the column names
library(readxl)
Birth <- read_excel("C:/Vital statistics in the UK.xlsx")
head(Birth)
colnames(Birth) 


# Convert to numeric and remove Null values
Birth$`Number of live births: United Kingdom` <- as.numeric(Birth$`Number of live births: United Kingdom`)
Birth <- Birth %>% filter(!is.na(`Number of live births: United Kingdom`))

# Create time series
Birth_ts <- ts(Birth$`Number of live births: United Kingdom`, start = min(Birth$Year), frequency = 1)


# Plotting the moving average
library(ggplot2)
autoplot(Birth_ts) +
  autolayer(Birth_ma, series = "5-Year Moving Average", color = "blue") +
  ggtitle("Number of Live Births in the UK with Moving Average Trend") +
  xlab("Year") +
  ylab("Number of Live Births") +
  theme_minimal()



# Augmented Dickey-Fuller Test
library(tseries)
adf.test(Birth_ts)
# Differencing
Birth_diff <- diff(Birth_ts, differences = 1)


# Forecasting
model_arima <- auto.arima(Birth_ts)
forecast_births <- forecast(model_arima, h = 10)

# Plot forecast
autoplot(forecast_births) +
  ggtitle("Forecast of Live Births in the UK") +
  xlab("Year") +
  ylab("Forecasted Number of Live Births")
























